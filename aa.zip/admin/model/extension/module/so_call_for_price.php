<?php

class ModelExtensionModuleSoCallForPrice extends Model {
	
}