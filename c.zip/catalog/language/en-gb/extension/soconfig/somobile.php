<?php
// Text
$_['text_home']          = 'Home';
$_['text_shopping_cart'] = 'Shopping Cart';
$_['text_account']       = 'My Account';
$_['text_register']      = 'Register';
$_['text_login']         = 'Login';
$_['text_logout']        = 'Logout';
$_['text_checkout']      = 'Checkout';
$_['text_search']        = 'Search';
$_['text_cart']        = 'Cart';
$_['text_all']           = 'Show All';
$_['text_more']       = 'More';
$_['text_language']       = 'Languages';
$_['text_currency']       = 'Currency';
$_['text_compare']       = 'Compare';
$_['text_itemcount']     = '<span class="items_cart">%s </span>';

$_['text_needhelp']      = 'Need Help';
$_['text_emailus']       = 'Email Us';
$_['text_morecategory']       = 'More Category';