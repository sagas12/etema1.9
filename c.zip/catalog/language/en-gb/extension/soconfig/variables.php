<?php
// Quickview
$_['button_detail'] 		  = 'Detail';
$_['text_category_stock_quantity']  = 'Hurry! only %s item(s) left!';

