<?php
// Heading
$_['heading_title'] = 'So Extra Slider';

// Text
$_['text_tax']      		= 'Ex Tax:';
$_['text_noproduct']      	= $_['heading_title'].': Has no item to show!';
$_['text_noitem']      	=  $_['heading_title'].': Has no item to show!';
$_['text_sale']      	= 'Sale';
$_['text_new']      	= 'New';