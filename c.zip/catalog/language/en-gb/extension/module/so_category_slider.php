<?php
// Heading
$_['heading_title'] = 'So categories slider';

// Text
$_['text_tax']      	= 'Ex Tax:';
$_['text_noitem']      	= 'Has no item to show!';
$_['text_sale']      	= 'Sale';
$_['text_new']      	= 'New';

$_['text_viewall']       = 'View All';