<?php
// Text
$_['input_check']           = "Don't show this popup again";
$_['label_email']           = "Enter Email";
$_['newsletter_placeholder']= "Your email address...";
$_['name_placeholder']= "Name";
$_['newsletter_button']     = "Subscribe";
$_['text_email_require']     = "Email Is Require";