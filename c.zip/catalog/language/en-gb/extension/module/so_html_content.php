<?php
// Heading
$_['heading_title'] = 'So Html Content';

// Text
$_['text_tax']      		= 'Ex Tax:';
$_['text_noproduct']      	= 'Has no item to show!';
$_['text_sale']      	= 'Sale';
$_['text_new']      	= 'New';