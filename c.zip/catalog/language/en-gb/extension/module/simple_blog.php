<?php

// Heading 
$_['heading_title']      	= 'Simple Blog';

$_['text_date_format']		= '<b>d</b> M';

$_['text_popular_all']		= 'Popular Articles';
$_['text_latest_all']		= 'Recent Posts';

$_['text_no_result']		= 'No Result!';
$_['text_comments']		= '&nbsp;comments';
$_['text_comment']		= '&nbsp;comment';
$_['show_all_text']		= 'See all';
