<?php


$_['text_noproduct']      	= ' Has no item to show!';
