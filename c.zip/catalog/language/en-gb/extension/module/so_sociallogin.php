<?php
// Heading
//$_['heading_title'] = 'So Social Login';
$_['text_colregister'] = '<h2>NEW HERE?</h2>
                            <p class="note-reg">Registration is free and easy!</p>
                            <ul class="list-log">
                                <li>Faster checkout</li>
                                <li>Save multiple shipping addresses</li>
                                <li>View and track orders and more</li>
                            </ul>';
$_['text_create_account']	= 'Create an account';
$_['text_forgot_password']	= 'Forgot Your Password?';
$_['text_title_popuplogin']	= 'Sign in Or Register';
$_['text_title_login_with_social']	= 'Login with your social account';