<?php
// Heading
$_['heading_title'] = 'So deals';

// Text
$_['text_tax']      		= 'Ex Tax:';
$_['text_noitem']      		= 'Has no item to show!';
$_['text_sale']      		= 'Sale';
$_['text_new']      		= 'New';
$_['text_time_left']      		= '<span>Hurry Up!</span> Offer ends in:';

$_['text_Day']      		= 'Day';
$_['text_Hour']      		= 'Hour';
$_['text_Min']      		= 'Min';
$_['text_Sec']      		= 'Sec';
$_['text_Days']      		= 'Days';
$_['text_Hours']      		= 'Hours';
$_['text_Mins']      		= 'Mins';
$_['text_Secs']      		= 'Secs';

$_['text_viewall']       = 'View All';
$_['text_available']    = 'Available:';
$_['text_sold']       	= 'Sold:';
