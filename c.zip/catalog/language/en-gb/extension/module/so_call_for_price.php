<?php

$_['error_name'] = "Name is Required.";
$_['error_email'] = "Email ID is Required.";
$_['error_number'] = "Contact Number is Required.";
$_['error_country'] = "Country is Required.";
$_['error_message'] = "Inquiry Details is Required.";

$_['text_success'] = "Thanks for your inquiry.";
$_['text_email_not_sent'] = "Email cannot sent.";

$_['text_subject'] = 'Call For Price for %s';