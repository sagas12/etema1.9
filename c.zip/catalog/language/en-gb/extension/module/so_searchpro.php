<?php
// Text
$_['text_search']    	= 'Search';
$_['text_category_all'] = 'All Category';
$_['text_brand_all'] = 'All Brand';
$_['text_tax']      	= 'Tax';
$_['text_price']      	= 'Price';
$_['button_cart']       = 'Add to Cart';
$_['button_wishlist']       = 'Add to Wish List';
$_['button_compare']       = 'Add to Compare';