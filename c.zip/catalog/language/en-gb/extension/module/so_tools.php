<?php

$_['text_history']			= 'History';
$_['text_shopping_cart']	= 'Shopping Cart';
$_['text_register']			= 'Register';
$_['text_account']			= 'Account';
$_['text_download']			= 'Download';
$_['text_login']			= 'Login';
$_['text_recent_products']	= 'Recent View Products';
$_['text_my_account']		= 'My Account';
$_['text_new']				= 'New';
$_['text_items_product']	= 'There are <span class="text-color">%s item(s)</span> in your cart';
$_['text_items']     	    = '<span class="items_cart">%s</span><span class="items_cart2"> item(s)</span><span class="items_carts"> - %s </span> ';
$_['button_cart']			= 'Add To Cart';
$_['text_search']			= 'Search';
$_['text_all_categories']	= 'All Categories';
$_['text_head_categories']	= 'Categories';
$_['text_head_cart']		= 'Cart';
$_['text_head_account']		= 'Account';
$_['text_head_search']		= 'Search';
$_['text_head_recent_view']	= 'Recent View';
$_['text_head_gotop']		= 'Go to Top';
$_['text_empty']               = 'Your shopping cart is empty!';
$_['text_no_content']               = 'Has no content to show !';