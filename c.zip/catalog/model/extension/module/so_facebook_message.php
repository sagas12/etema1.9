<?php

class ModelExtensionModuleSoFacebookMessage extends Model {
	
}